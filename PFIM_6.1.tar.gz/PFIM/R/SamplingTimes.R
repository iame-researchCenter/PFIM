#' Class "SamplingTimes"
#'
#' @description The class "SamplingTimes" implements the sampling times.
#'
#' @name SamplingTimes-class
#' @aliases SamplingTimes
#' @docType class
#' @include GenericMethods.R
#' @export
#'
#' @section Objects from the class \code{SamplingTimes}:
#' Objects form the class \code{SamplingTimes} can be created by calls of the form \code{SamplingTimes(...)} where
#' (...) are the parameters for the \code{SamplingTimes} objects.
#'
#' @section Slots for \code{SamplingTimes} objects:
#'  \describe{
#'    \item{\code{outcome}:}{A string giving the outcome.}
#'    \item{\code{samplings}:}{A vector giving the sampling times.}
#'  }

SamplingTimes = setClass(Class="SamplingTimes",
                         representation=representation
                         (
                           outcome = "character",
                           samplings ="vector"
                         ))

#' initialize
#' @param .Object .Object
#' @param outcome outcome
#' @param samplings samplings
#' @return SamplingTimes
#' @export
#'
setMethod( f="initialize",
           signature="SamplingTimes",
           definition= function (.Object, outcome, samplings )
           {
             if(!missing(outcome))
             {
               .Object@outcome = outcome
             }
             if(!missing(samplings))
             {
               .Object@samplings = samplings
             }
             validObject(.Object)
             return (.Object )
           }
)

# ======================================================================================================
# getOutcome
# ======================================================================================================

#' @rdname getOutcome
#' @export

setMethod("getOutcome",
          "SamplingTimes",
          function(object)
          {
            return(object@outcome)
          }
)


# ======================================================================================================
# setOutcome
# ======================================================================================================

#' @rdname setOutcome
#' @export
#'
setMethod("setOutcome",
          "SamplingTimes",
          function(object, outcome)
          {
            object@outcome = outcome
            return(object)
          }
)

# ======================================================================================================
# getSamplings
# ======================================================================================================

#' @rdname getSamplings
#' @export
#'
setMethod("getSamplings",
          "SamplingTimes",
          function(object)
          {
            return(object@samplings)
          }
)

#' Set the sampling times.
#'
#' @name setSamplings
#' @param object An object from the class \linkS4class{SamplingTimes}.
#' @param samplings A vector giving the sampling times.
#' @return The updated sampling times.
#' @export

setGeneric("setSamplings",
           function(object, samplings)
           {
             standardGeneric("setSamplings")
           }
)

#' @rdname setSamplings
#' @export
#'
setMethod("setSamplings",
          "SamplingTimes",
          function(object, samplings)
          {
            object@samplings = samplings
            return(object)
          }
)

# ########################################################################################################################
# END Class SamplingTimes
# ########################################################################################################################




